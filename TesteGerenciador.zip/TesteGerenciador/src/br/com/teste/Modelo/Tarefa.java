package br.com.teste.Modelo;

public class Tarefa {

}
