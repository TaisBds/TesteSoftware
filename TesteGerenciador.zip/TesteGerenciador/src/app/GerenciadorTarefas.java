package app;

import modelo.Tarefa;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
        
public class GerenciadorTarefas {
    static Scanner scanner = new Scanner(System.in);
    static List<Tarefa> tarefas = new ArrayList<>();
    static int contadorId = 1;
    
    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Criar\n2. Listar\n3. Atualizar\n4. Remover\n5. Buscar\n6. Sair");
            System.out.print("Escolha: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> criar();
                case 2 -> listar();
                case 3 -> atualizar();
                case 4 -> remover();
                case 5 -> buscar();
                case 6 -> System.exit(0);
                default -> System.out.println("Opção inválida.");
            }
        }
    }
        
    static void criar() {
        System.out.print("Descrição da tarefa: ");
        String descricao = scanner.nextLine();
        tarefas.add(new Tarefa(contadorId++, descricao));
        System.out.println("Tarefa criada com sucesso.");
    }

    static void listar() {
        if (tarefas.isEmpty()) {
            System.out.println("Nenhuma tarefa cadastrada.");
        } else {
            tarefas.forEach(System.out::println);
        }
    }

    static void atualizar() {
        System.out.print("ID da tarefa para atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        for (Tarefa t : tarefas) {
            if (t.id == id) {
                System.out.print("Nova descrição: ");
                t.descricao = scanner.nextLine();
                System.out.println("Tarefa atualizada.");
                return;
            }
        }
        System.out.println("Tarefa não encontrada.");
    }

    static void remover() {
        System.out.print("ID da tarefa para remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        tarefas.removeIf(t -> t.id == id);
        System.out.println("Tarefa removida.");
    }

    static void buscar() {
        System.out.print("Palavra-chave para busca: ");
        String termo = scanner.nextLine().toLowerCase();
        tarefas.stream()
               .filter(t -> t.descricao.toLowerCase().contains(termo))
               .forEach(System.out::println);
    }
}